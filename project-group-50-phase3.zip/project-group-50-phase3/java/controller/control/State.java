package controller.control;

public enum State {
    EXIT,
    LOGIN,
    SIGN,
    PROFILE,
    MAP,
    GAME,
    GOVERNMENT, TRADE, SHOP,
}
