package model.Massenger;

import java.io.Serializable;

public enum ChatType implements Serializable {
    GROUP,
    CHANNEL,
    PRIVATE_CHAT,
    NOT_SET
}
