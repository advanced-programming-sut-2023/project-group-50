package model.ObjectsPackage.People;

public enum PersonState {
    JOBLESS,
    WORKER,
    DEPLOYED_SOLDIER,
    UNDEPLOYED_SOLDIER

}
