package model.ObjectsPackage.People.Soldier;

public enum GroupModeName {
    ARCHER,
    ENGINEER,
    INFANTRY,
    TUNNELER
}
